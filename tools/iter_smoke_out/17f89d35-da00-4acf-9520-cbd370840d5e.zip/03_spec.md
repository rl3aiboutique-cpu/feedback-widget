# Compliance Review Kanban Board

A vertical Kanban board for tracking compliance reviews with drag-and-drop functionality.

## Routing
_Section id: `sec_routing`_

- **New Route**: `/reviews/board` (Kanban view)
- **Existing Route**: `/reviews/list` (List view fallback)

## Permissions
_Section id: `sec_permissions`_

- **Drag-and-Drop**: Restricted to users with the `Compliance Officer` role. Users with the `Reviewer` role have read-only access to the board.

## Performance
_Section id: `sec_performance`_

- **UI Latency**: Drag-and-drop transitions must be highly responsive. The visual movement of a card between columns must complete within 200ms of the drop event.

