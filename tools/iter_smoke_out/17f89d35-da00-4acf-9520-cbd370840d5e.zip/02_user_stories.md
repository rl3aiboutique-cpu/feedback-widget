# User Stories

## Compliance Officer

### View reviews on a Kanban board

_Story id: `us_co_view_board`_


**As a** compliance officer, **I want** to view reviews on a vertical Kanban board, **so that** I can see the status of all reviews at a glance without horizontal scrolling.


**Scenario:** Viewing the board

- **Given** I am on the `/reviews/board` route
- **When** the page loads
- **Then** I see vertical columns representing different review statuses within 500ms of page load

### Update review status via drag-and-drop

_Story id: `us_co_dnd_status`_


**As a** compliance officer, **I want** to drag review cards between columns, **so that** I can update the status of a review quickly.


**Scenario:** Moving a card

- **Given** a review card is in the "Pending" column
- **When** I drag the card to the "In Flight" column
- **Then** the review's status is updated in the system
- **Then** the card moves to the new column within 200ms

## Reviewer

### Access list view fallback

_Story id: `us_reviewer_access_list`_


**As a** reviewer, **I want** to access the existing list view, **so that** I can use the traditional view if preferred.


**Scenario:** Navigating to list view

- **Given** I am on the `/reviews/board` route
- **When** I navigate to `/reviews/list`
- **Then** I see the original list-based view of reviews

### View-only access to Kanban board

_Story id: `us_reviewer_view_only`_


**As a** reviewer, **I want** to view the Kanban board without being able to move cards, **so that** I don't accidentally change the status of a review.


**Scenario:** Attempting to drag as a reviewer

- **Given** I am logged in as a Reviewer
- **When** I attempt to drag a review card
- **Then** the card remains in its original position
- **Then** no API call is triggered to update status

