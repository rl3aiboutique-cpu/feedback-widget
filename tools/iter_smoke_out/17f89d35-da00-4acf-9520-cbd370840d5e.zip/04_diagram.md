# Role-based access control for Kanban board interactions

```mermaid
graph LR
  A[User] --> B{Role?}
  B -- Compliance Officer --> C[Can Drag & Drop]
  B -- Reviewer --> D[View Only]
  C --> E[Update Status API]
  D --> F[No API Call]
```
