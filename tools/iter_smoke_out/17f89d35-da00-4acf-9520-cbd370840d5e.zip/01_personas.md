# Personas

## Compliance Officer — Compliance Lead

_Persona id: `p_compliance_officer`_


**Goals**

- Manage the compliance review pipeline efficiently
- Quickly identify pending vs. in-flight reviews

**Pain points**

- Horizontal scrolling in the current list view to see status
- Manual status updates are slow

**Context**

Uses the platform to oversee the lifecycle of compliance reviews.

## Reviewer — Compliance Analyst

_Persona id: `p_reviewer`_


**Goals**

- Focus on reviews currently "In Flight"
- Move completed reviews to the next stage

**Pain points**

- Difficulty seeing workload distribution

**Context**

Performs the actual review work and updates statuses as they progress.

