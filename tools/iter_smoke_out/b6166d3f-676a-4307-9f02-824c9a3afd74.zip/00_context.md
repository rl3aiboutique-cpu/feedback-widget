# Original Feedback

## Title

Smoke test — iter end-to-end

## Description

Users want to track the status of their compliance reviews on a kanban-style board so they can see what's pending vs in flight at a glance. The current list view forces them to scroll horizontally to see the status column. We want a vertical column-based layout instead, with drag-and-drop between statuses.

## Expected Outcome

A new /reviews/board route with one column per review status. Cards drag between columns to update status. The existing list view stays as a fallback under /reviews/list.

## Technical Metadata

- url: `http://localhost:3001/reviews`
- route: `/_layout/reviews`
- app_version: `0.2.0`
- git_commit_sha: `abcdef0123456789`

### Captured metadata bundle

```json
{
  "viewport": {
    "dpr": 1,
    "width": 1440,
    "height": 900
  },
  "framework": "react",
  "console_tail": [],
  "network_tail": []
}
```

## Attachments

(none)
