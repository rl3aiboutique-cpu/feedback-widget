# Personas

## Compliance Officer — Reviewer

_Persona id: `p_compliance_officer`_


**Goals**

- Quickly identify which reviews are pending action.
- Efficiently move reviews through the lifecycle.
- Get a high-level visual overview of workload.

**Pain points**

- Horizontal scrolling in the current list view to find status.
- High cognitive load when trying to gauge progress from a table.

**Context**

Works within the `/reviews` route to manage daily compliance tasks.

## Compliance Manager — Supervisor

_Persona id: `p_compliance_manager`_


**Goals**

- Monitor the volume of reviews in each stage.
- Identify stages where reviews are getting stuck.

**Pain points**

- Difficulty seeing the "big picture" of the review pipeline.

**Context**

Uses the dashboard to ensure compliance deadlines are met.

