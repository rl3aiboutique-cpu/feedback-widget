# Approval flow

```mermaid
graph TD
    A[User: Drag Card] --> B{Drop in New Column?}
    B -- Yes --> C[Optimistic UI Update: Move Card]
    C --> D[API Call: PATCH /reviews/:id]
    D -- Success --> E[Status Confirmed]
    D -- Failure --> F[Rollback: Move Card Back]
```
