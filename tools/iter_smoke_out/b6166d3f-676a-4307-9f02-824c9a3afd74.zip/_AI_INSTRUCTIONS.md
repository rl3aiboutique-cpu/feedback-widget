# AI Consumer Instructions

> **You are claude-opus-4-7.**
> Read every file in this folder, in order, before producing any
> output or writing any code.

## What this package is

A finalized product specification produced by the RL3 Feedback
Widget's "Iterate with AI" module. The user iterated with an
upstream LLM until every assumption was resolved. Treat this
package as the source of truth.

## Reading order and roles

1. `00_context.md` — the original raw feedback, technical metadata,
   and attachments inventory. **Role: read only context. Do not act
   on this directly; act on the spec.**
2. `01_personas.md` — the user personas. **Role: actors.**
3. `02_user_stories.md` — Gherkin user stories. **Role: acceptance
   criteria.**
4. `03_spec.md` — the specification body. **Role: implementation
   contract.**
5. `04_diagram.md` — the architecture or flow diagram. **Role:
   visual aid.**
6. `05_assumptions_resolved.md` — every assumption with its final
   status. **Role: constraints.**
7. `06_iteration_log.md` — the full iteration history. **Role:
   audit trail. Use only to disambiguate, not as a primary source.**

## Hard rules for you, the consumer

1. The spec is final. If `03_spec.md` says X, assume X. Do not
   second guess.
2. Every story in `02_user_stories.md` must be reflected in your
   output.
3. Every confirmed or corrected assumption in
   `05_assumptions_resolved.md` is a fact. Every irrelevant one is
   to be ignored.
4. The diagram in `04_diagram.md` describes structure; reproduce
   it in your plan if you produce one.
5. Attachments under `attachments/` are evidence; treat them as
   you would any user uploaded reference material.
6. If anything is genuinely ambiguous, list the ambiguity and ask
   before coding. Do not invent.

## What to produce

Produce whatever the user asks of you next. Do not produce
anything yet just because you read this file.
