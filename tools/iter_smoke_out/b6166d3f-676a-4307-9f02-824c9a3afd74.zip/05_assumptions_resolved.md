# Assumptions Resolved

| slot_key | kind | status | statement | user response |
| --- | --- | --- | --- | --- |
| `asm_status_dynamic` | technical | corrected | Columns are dynamically generated based on the existing review status enum/values. | Use the existing 'Compliance Officer' role; don't create a new persona. |
| `asm_api_patch` | technical | confirmed | An existing API endpoint exists to PATCH the status of a review. |  |
| `asm_drag_permission_role` | ux | confirmed | Only users with the 'Compliance Officer' role can perform drag-and-drop actions. |  |

## Marked irrelevant

- `asm_card_content` — Cards will display the Review ID and Title as primary information.
