# User Stories

## Compliance Officer

### Kanban Overview

_Story id: `us_compliance_officer_kanban_overview`_


**As a** compliance officer, **I want** to view reviews on a Kanban-style board, **so that** I can see the status of all reviews at a glance without horizontal scrolling.


**Scenario:** Viewing the board

- **Given** I am on the reviews page
- **When** I navigate to `/reviews/board`
- **Then** I see a vertical column-based layout where each column represents a review status within 200ms of navigation.

### Drag-and-Drop Status Update

_Story id: `us_compliance_officer_drag_drop`_


**As a** compliance officer, **I want** to drag review cards between columns, **so that** I can update their status quickly and intuitively.


**Scenario:** Moving a review to a new status

- **Given** a review card is in the "Pending" column
- **When** I drag the card to the "In Flight" column and release it
- **Then** the review status is updated in the system and the card moves to the new column within 200ms of release.

### Access List View Fallback

_Story id: `us_compliance_officer_list_fallback`_


**As a** compliance officer, **I want** to be able to switch back to the list view, **so that** I can access the existing detailed tabular data.


**Scenario:** Switching views

- **Given** I am viewing the Kanban board
- **When** I navigate to `/reviews/list`
- **Then** I see the original list view as it currently exists within 200ms of navigation.

