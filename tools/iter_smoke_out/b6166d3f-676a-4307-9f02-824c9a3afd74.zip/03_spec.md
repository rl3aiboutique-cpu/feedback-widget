# Compliance Review Kanban Board

Implement a new Kanban board view for compliance reviews to improve visibility and streamline status updates via drag-and-drop interaction.

## Routing & Navigation
_Section id: `sec_routing`_

- **New Route**: `/reviews/board`
- **Existing Route**: `/reviews/list` (must remain unchanged and functional).
- **Navigation**: Provide a way to toggle between Board and List views (e.g., a view switcher component).

## UI Components
_Section id: `sec_ui`_

- **Kanban Container**: A horizontal scrolling container (if columns exceed viewport) containing vertical columns.
- **Status Columns**: 
  - Dynamically generated based on available review statuses.
  - Each column must have a header displaying the status name and a count of cards within it.
- **Review Cards**: 
  - Minimalist cards containing key review identifiers (e.g., Review ID, Title, Owner).
  - Must be draggable.

## Interaction Model
_Section id: `sec_interaction`_

- **Drag-and-Drop**:
  - Implement using a React-compatible DnD library (e.g., `@dnd-kit` or `react-beautiful-dnd`).
  - On `onDragEnd`, trigger an API call to update the review's status.
  - Implement optimistic UI updates to ensure the card moves immediately, with rollback on API failure.
- **Permissions**: Only users with the 'Compliance Officer' role are permitted to initiate drag-and-drop actions.
- **Performance**: UI updates (optimistic) must occur within 200ms of the user action.

