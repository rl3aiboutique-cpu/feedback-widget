# Iteration Log

| version | timestamp (UTC) | restructure | user message | changes summary |
| --- | --- | --- | --- | --- |
| 1 | 2026-05-05T22:41:22.705244+00:00 | no |  |  |
| 2 | 2026-05-05T22:46:01.213972+00:00 | no | Tighten the spec: only Compliance Officers can drag cards. Make Then statements measurable (e.g., 'card moves within 200 | Updated user stories to include measurable acceptance criteria (200ms threshold) and added specific permission and performance requirements to the Interaction Model in the specification. |
